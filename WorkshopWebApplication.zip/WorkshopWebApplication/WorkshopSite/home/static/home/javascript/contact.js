function showInfo() {
    prompt("\nDane kontaktowe:\n\nTelefon: (+48) 745-661-348\nAdres: ul.Dunikowskiego 8, 44-100, Gliwice\n\nE-mail:", "stanislaw.kowalski@workshop.pl");
}