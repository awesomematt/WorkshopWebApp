# Workshop Web Application Project
# Authors: Mateusz Jachimczak & Dawid Pawłowski
# Silesian Univeristy of Technology, Gliwice, Poland
# GitHub: https://github.com/yellowmatt/WorkshopWebApp

from django.contrib import admin

from .models import Service

admin.site.register(Service)
